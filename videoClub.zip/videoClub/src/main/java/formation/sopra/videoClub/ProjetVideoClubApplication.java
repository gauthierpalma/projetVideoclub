package formation.sopra.videoClub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetVideoClubApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetVideoClubApplication.class, args);
	}

}
